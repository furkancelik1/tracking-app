(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_recharts_es6_util_0k8ro6e._.js","static/chunks/node_modules_recharts_es6_state_0d7bkjz._.js","static/chunks/node_modules_recharts_es6_component_0d9cnvp._.js","static/chunks/node_modules_recharts_es6_cartesian_0n-dh4p._.js","static/chunks/node_modules_recharts_es6_0z9hv.k._.js","static/chunks/node_modules_0j8u2x-._.js","static/chunks/src_components_dashboard_ActivityAreaChart_tsx_0l5.8hx._.js"],
    source: "dynamic"
});
