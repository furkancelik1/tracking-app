(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_recharts_es6_0-4_dxa._.js","static/chunks/node_modules_0nd3pjb._.js","static/chunks/src_components_dashboard_ConsistencyRadarChart_tsx_0uftfbm._.js"],
    source: "dynamic"
});
