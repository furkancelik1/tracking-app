(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_recharts_es6_0wrovxj._.js","static/chunks/node_modules_0sb8uo6._.js","static/chunks/src_components_dashboard_CategoryPieChart_tsx_0x0nzek._.js"],
    source: "dynamic"
});
