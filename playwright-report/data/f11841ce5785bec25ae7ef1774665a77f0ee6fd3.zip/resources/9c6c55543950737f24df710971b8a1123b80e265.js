(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_dashboard_DailyDisciplineGauge_tsx_0_3z3tu._.js","static/chunks/src_04epp9-._.js","static/chunks/node_modules_next_0p1a5yu._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_0.bj-n9._.js"],
    source: "dynamic"
});
