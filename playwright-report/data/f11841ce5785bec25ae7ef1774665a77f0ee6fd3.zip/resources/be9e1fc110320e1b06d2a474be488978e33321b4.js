(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/dashboard/DailyDisciplineGauge.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_recharts_es6_00ft~ly._.js",
  "static/chunks/node_modules_13n4zfd._.js",
  "static/chunks/src_components_06utdgc._.js",
  "static/chunks/src_components_dashboard_DailyDisciplineGauge_tsx_09nz6u6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/dashboard/DailyDisciplineGauge.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);