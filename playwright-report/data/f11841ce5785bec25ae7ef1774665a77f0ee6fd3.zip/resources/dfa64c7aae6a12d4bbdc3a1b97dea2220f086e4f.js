(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_framer-motion_dist_es_03co3hq._.js","static/chunks/node_modules_motion-dom_dist_es_0oitghd._.js","static/chunks/node_modules_0b-irsk._.js","static/chunks/src_components_0v~ba_b._.js","static/chunks/[next]_internal_font_google_inter_e798e1f6_module_0zpa5wf.css"],
    source: "dynamic"
});
