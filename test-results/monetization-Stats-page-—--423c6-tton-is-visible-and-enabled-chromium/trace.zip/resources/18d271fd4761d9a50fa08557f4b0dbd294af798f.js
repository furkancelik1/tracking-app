(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_dashboard_0c7hmb0._.js","static/chunks/src_080-9mo._.js","static/chunks/node_modules_0x~fkmp._.js"],
    source: "dynamic"
});
