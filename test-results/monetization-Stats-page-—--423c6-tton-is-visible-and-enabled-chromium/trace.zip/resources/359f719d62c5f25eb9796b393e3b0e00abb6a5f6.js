(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/dashboard/ActivityAreaChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_recharts_es6_util_0k8ro6e._.js",
  "static/chunks/node_modules_recharts_es6_state_0d7bkjz._.js",
  "static/chunks/node_modules_recharts_es6_component_0d9cnvp._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_0n-dh4p._.js",
  "static/chunks/node_modules_recharts_es6_0z9hv.k._.js",
  "static/chunks/node_modules_0j8u2x-._.js",
  "static/chunks/src_components_dashboard_ActivityAreaChart_tsx_0l5.8hx._.js",
  "static/chunks/src_components_dashboard_ActivityAreaChart_tsx_0y~hc4z._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/dashboard/ActivityAreaChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/dashboard/CategoryPieChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_recharts_es6_0wrovxj._.js",
  "static/chunks/node_modules_0sb8uo6._.js",
  "static/chunks/src_components_dashboard_CategoryPieChart_tsx_0x0nzek._.js",
  "static/chunks/src_components_dashboard_CategoryPieChart_tsx_0y~hc4z._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/dashboard/CategoryPieChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/dashboard/ConsistencyRadarChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_recharts_es6_0-4_dxa._.js",
  "static/chunks/node_modules_0nd3pjb._.js",
  "static/chunks/src_components_dashboard_ConsistencyRadarChart_tsx_0uftfbm._.js",
  "static/chunks/src_components_dashboard_ConsistencyRadarChart_tsx_0y~hc4z._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/dashboard/ConsistencyRadarChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);